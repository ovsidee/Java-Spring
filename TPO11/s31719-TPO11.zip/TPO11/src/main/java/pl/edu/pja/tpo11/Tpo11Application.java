package pl.edu.pja.tpo11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tpo11Application {

    public static void main(String[] args) {
        SpringApplication.run(Tpo11Application.class, args);
    }

}
