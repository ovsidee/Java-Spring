package pl.edu.pja.tpo11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tpo11ApplicationTests {

    @Test
    void contextLoads() {
    }

}
