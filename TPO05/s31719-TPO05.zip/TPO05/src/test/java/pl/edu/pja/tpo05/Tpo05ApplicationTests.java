package pl.edu.pja.tpo05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tpo05ApplicationTests {

    @Test
    void contextLoads() {
    }

}
