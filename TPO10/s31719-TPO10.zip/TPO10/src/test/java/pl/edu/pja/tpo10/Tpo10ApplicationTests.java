package pl.edu.pja.tpo10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tpo10ApplicationTests {

    @Test
    void contextLoads() {
    }

}
