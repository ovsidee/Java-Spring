package pl.edu.pja.s31719tpo04blog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S31719Tpo04BlogApplicationTests {

    @Test
    void contextLoads() {
    }

}
