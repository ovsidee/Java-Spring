package pl.edu.pja.s31719tpo04books;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S31719Tpo04BooksApplicationTests {

    @Test
    void contextLoads() {
    }

}
