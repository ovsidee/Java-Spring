package pl.edu.pja.tpo07;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tpo07ApplicationTests {

    @Test
    void contextLoads() {
    }

}
