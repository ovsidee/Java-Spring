package pl.edu.pja.tpo03;

public interface FileService {
    void loadWords();
    void saveWordToFile(Entry entry);
}
