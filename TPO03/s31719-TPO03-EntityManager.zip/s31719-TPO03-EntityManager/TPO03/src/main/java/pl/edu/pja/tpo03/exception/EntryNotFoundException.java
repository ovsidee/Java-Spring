package pl.edu.pja.tpo03.exception;

public class EntryNotFoundException extends Exception {}
