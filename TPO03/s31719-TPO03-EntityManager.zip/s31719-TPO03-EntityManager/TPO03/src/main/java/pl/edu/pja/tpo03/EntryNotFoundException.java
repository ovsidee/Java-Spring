package pl.edu.pja.tpo03;

public class EntryNotFoundException extends Exception {}
