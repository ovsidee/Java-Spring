package pl.edu.pja.tpo03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlashcardsAppTests {

    @Test
    void contextLoads() {
    }

}
